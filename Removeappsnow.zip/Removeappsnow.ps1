﻿

<#

   PRorgrams and features                                                                                      __                  __        __                                __                                     
                                                                                          |  \                |  \      |  \                              |  \                                    
  ______    ______    ______    ______    ______    ______   ______ ____    _______        \$$ _______        | $$____  | $$  ______    ______    _______ | $$____    ______    ______    _______ 
 /      \  /      \  /      \  /      \  /      \  |      \ |      \    \  /       \      |  \|       \       | $$    \ | $$ /      \  |      \  /       \| $$    \  /      \  /      \  /       \
|  $$$$$$\|  $$$$$$\|  $$$$$$\|  $$$$$$\|  $$$$$$\  \$$$$$$\| $$$$$$\$$$$\|  $$$$$$$      | $$| $$$$$$$\      | $$$$$$$\| $$|  $$$$$$\  \$$$$$$\|  $$$$$$$| $$$$$$$\|  $$$$$$\|  $$$$$$\|  $$$$$$$
| $$  | $$| $$   \$$| $$  | $$| $$  | $$| $$   \$$ /      $$| $$ | $$ | $$ \$$    \       | $$| $$  | $$      | $$  | $$| $$| $$    $$ /      $$| $$      | $$  | $$| $$    $$| $$   \$$ \$$    \ 
| $$__/ $$| $$      | $$__/ $$| $$__| $$| $$      |  $$$$$$$| $$ | $$ | $$ _\$$$$$$\      | $$| $$  | $$      | $$__/ $$| $$| $$$$$$$$|  $$$$$$$| $$_____ | $$  | $$| $$$$$$$$| $$       _\$$$$$$\
| $$    $$| $$       \$$    $$ \$$    $$| $$       \$$    $$| $$ | $$ | $$|       $$      | $$| $$  | $$      | $$    $$| $$ \$$     \ \$$    $$ \$$     \| $$  | $$ \$$     \| $$      |       $$
| $$$$$$$  \$$        \$$$$$$  _\$$$$$$$ \$$        \$$$$$$$ \$$  \$$  \$$ \$$$$$$$        \$$ \$$   \$$       \$$$$$$$  \$$  \$$$$$$$  \$$$$$$$  \$$$$$$$ \$$   \$$  \$$$$$$$ \$$       \$$$$$$$ 
| $$                          |  \__| $$                                                                                                                                                          
| $$                           \$$    $$                                                                                                                                                          
 \$$                            \$$$$$$                                                                                                                                                           


Get them out of the bleacher in HCI OS! 

#>


function Show-Menu {
    param (
        [string]$Title = 'PR in bleachers remove'
    )
    Clear-Host
    Write-Host "================ $Application Remove Menu ================"
    
    Write-Host "1: Press '1' THE BEST app to get removal strings for all apps."
    Write-Host "2: Press '2' To get MSI Installer removal command from registry."
    Write-Host "3: Press '3' To see and remove WMI metadata by name for removed driver or application."
    Write-Host "4: Press '4' To see and recent installs and there success or fail codes."
    Write-Host "Q: Press 'Q' to quit."
}



function Get-InstalledSoftware {
    <#
	.SYNOPSIS
		Retrieves a list of all software installed on a Windows computer.
	.EXAMPLE
		PS> Get-InstalledSoftware
		
		This example retrieves all software installed on the local computer.
	.PARAMETER ComputerName
		If querying a remote computer, use the computer name here.
	
	.PARAMETER Name
		The software title you'd like to limit the query to.
	
	.PARAMETER Guid
		The software GUID you'e like to limit the query to
	#>
    [CmdletBinding()]
    param (
		
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName = $env:COMPUTERNAME,
		
        [Parameter(mandatory=$false)]
        [string]$Name,
		
        [Parameter(mandatory=$false)]
        [string]$Guid
    )
    process {
        try {
            $scriptBlock = {
                $args[0].GetEnumerator() | ForEach-Object { New-Variable -Name $_.Key -Value $_.Value }
				
                $UninstallKeys = @(
                    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
                    "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
                )
                New-PSDrive -Name HKU -PSProvider Registry -Root Registry::HKEY_USERS | Out-Null
                $UninstallKeys += Get-ChildItem HKU: | where { $_.Name -match 'S-\d-\d+-(\d+-){1,14}\d+$' } | foreach {
                    "HKU:\$($_.PSChildName)\Software\Microsoft\Windows\CurrentVersion\Uninstall"
                }
                if (-not $UninstallKeys) {
                    Write-Warning -Message 'No software registry keys found'
                } else {
                    foreach ($UninstallKey in $UninstallKeys) {
                        $friendlyNames = @{
                            'DisplayName'    = 'Name'
                            'DisplayVersion' = 'Version'
                        }
                        Write-Verbose -Message "Checking uninstall key [$($UninstallKey)]"
                        if ($Name) {
                            $WhereBlock = { $_.GetValue('DisplayName') -like "$Name*" }
                        } elseif ($GUID) {
                            $WhereBlock = { $_.PsChildName -eq $Guid.Guid }
                        } else {
                            $WhereBlock = { $_.GetValue('DisplayName') }
                        }
                        $SwKeys = Get-ChildItem -Path $UninstallKey -ErrorAction SilentlyContinue | Where-Object $WhereBlock
                        if (-not $SwKeys) {
                            Write-Verbose -Message "No software keys in uninstall key $UninstallKey"
                        } else {
                            foreach ($SwKey in $SwKeys) {
                                $output = @{ }
                                foreach ($ValName in $SwKey.GetValueNames()) {
                                    if ($ValName -ne 'Version') {
                                        $output.InstallLocation = ''
                                        if ($ValName -eq 'InstallLocation' -and 
                                            ($SwKey.GetValue($ValName)) -and 
                                            (@('C:', 'C:\Windows', 'C:\Windows\System32', 'C:\Windows\SysWOW64') -notcontains $SwKey.GetValue($ValName).TrimEnd('\'))) {
                                            $output.InstallLocation = $SwKey.GetValue($ValName).TrimEnd('\')
                                        }
                                        [string]$ValData = $SwKey.GetValue($ValName)
                                        if ($friendlyNames[$ValName]) {
                                            $output[$friendlyNames[$ValName]] = $ValData.Trim() ## Some registry values have trailing spaces.
                                        } else {
                                            $output[$ValName] = $ValData.Trim() ## Some registry values trailing spaces
                                        }
                                    }
                                }
                                $output.GUID = ''
                                if ($SwKey.PSChildName -match '\b[A-F0-9]{8}(?:-[A-F0-9]{4}){3}-[A-F0-9]{12}\b') {
                                    $output.GUID = $SwKey.PSChildName
                                }
                                  Write-host "-----------------------------------------------------------------------------------------------------------"
                                New-Object -TypeName PSObject -Prop $output
                               
                            }
                        }
                    }
                }
            }
			
            if ($ComputerName -eq $env:COMPUTERNAME) {
                & $scriptBlock $PSBoundParameters
                
            } else {
                Invoke-Command -ComputerName $ComputerName -ScriptBlock $scriptBlock -ArgumentList $PSBoundParameters
               
            }
        } catch {
            Write-Error -Message "Error: $($_.Exception.Message) - Line Number: $($_.InvocationInfo.ScriptLineNumber)"
        }
    }
}


Function Get-myremovalinfo {

       clear-host
       $name=""
       $myhost= $env:COMPUTERNAME
          $readnameGuid= "5"
          $readNameGuid = read-host "Choose 1 for a name search. choose 5 enter, for open search"
    If ($readNameGuid -eq "1"){
                               $name = Read-host "ENter a title you are lookng for if you have one"
                               Get-InstalledSoftware $env:COMPUTERNAME $name}
                                If ($readNameGuid -eq "2"){ $guid= read-host " enter the numeric guid if you have one" ; Get-InstalledSoftware $myhost $guid }
  
                              If ($readNameGuid -gt "2") { Get-InstalledSoftware $myhost}


}

Function msiexecreg {

Get-AppxPackage –AllUsers | Select Name, PackageFullName.


$InstalledSoftware = Get-ChildItem "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall"
foreach($obj in $InstalledSoftware){write-host $obj.GetValue('DisplayName') -NoNewline; write-host " - " -NoNewline; write-host $obj.GetValue('DisplayVersion')}






}



Function AttemptWMIFix
{

Clear-host
Write-host " This Script will attempt to remove WMI entries. "
Write-host " You will see a get command. Based on those results, copy any name you want to remove."
Write-host " You will be able remove in section 2"
write-host " This is a dangerous operation that will wreck your machine if not used correctly"
Write-host " This is for removing bad metadata only!!!! You have been warned"

Read-host "hit enter to begin" 

$pcname= $env:computername
Get-WmiObject Win32_Product -ComputerName $pcname | select Name,Version

 $pickuperrr = Read-host " copy and paste a name value that is in this list but not installed anywhere else. Then hit enter"

 Write-host "removing..." 
# to remove 
Get-WmiObject Win32_Product | where-Object {$_.name -Like $pickuperrr} | ForEach-Object { $_.Uninstall() }

Get-WmiObject Win32_Product -Filter "name LIKE $pickuperrr" | ForEach-Object { $_.Uninstall() }

Write-host "success" ; sleep(5)

Clear-host

Write-host "Now that you have cleared this, If it still shows in the list of apps in  sections 1 or 2 of this app "
Wrte-host " You will need to edit find the registry for Computer\HKEY_CURRENT_USER\Software\Microsoft\Installer\Products\"
Write-host " ise this link to help in the search "
Write-host "https://learn.microsoft.com/en-us/troubleshoot/windows-server/application-management/fix-software-update-registration-issues"
Write-host " There should be a guid that you can pick up from the products registry key - delete all locations of this guid and try again"
Write-host "Once you start searching for the guid there may be a dozen locations, for example "
Write-host "Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-21-2996261308-3948512954-139610935-1002\Components\00EC1FE00D825224698B6FF8DEF14CFC"
Read-host " Hit a key to exit this section"
Write-host "Your a rip in the Hip! Thank you goodnight" ; Sleep(5)


}


function RecentInstall {

Clear-host
Read-host " Hit a key to continue. This will dump recent MSI installer apps with error codes"

# shows recent installations including language packs and error status 0 is good 1603 perhaps not so much 

Get-WinEvent -ProviderName msiinstaller | where id -eq 1033 | select timecreated,message | FL *


}


do
 {
    Show-Menu
    $selection = Read-Host "Please make a selection"
    switch ($selection)
    {
    '1' {'You chose option 1'
        get-myremovalinfo
    } '2' {
    'You chose option #2'
    msiexecreg
    } '3' {
      'You chose option #3'
      AttemptWMIFix
    } '4' {
      'You chose option #4'
      RecentInstall
    }
    }
    pause
 }
 until ($selection -eq 'q')
